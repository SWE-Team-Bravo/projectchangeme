// Formatts all sheets
function spreadsheetFormatting() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheets = spreadsheet.getSheets();

  for(let i = 3; i < sheets.length - 1; ++i) {
    const sheet = sheets[i];
    const range = sheet.getDataRange();

    range.clearFormat();
    range.setFontFamily('Roboto');
    range.setFontSize(11);

    range.setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP);
    range.setHorizontalAlignment("left");
  }

  highlightAttendance();
  highlightWaivers();
}

// Highlights attendance
function highlightAttendance() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getSheetByName("Attendance");
  const range = sheet.getDataRange();
  const cellValues = range.getValues();

  // Color headers black
  if(!range.getBandings) range.applyRowBanding(SpreadsheetApp.BandingTheme.LIGHT_GREY);
  sheet.getRange(1, 1, 1, sheet.getLastColumn()).setBackground("#000000");
  sheet.getRange(1, 1, 1, sheet.getLastColumn()).setFontColor("#FFFFFF");
  
  // Color subheaders darkgrey
  const subHeaderSize = 3;
  for(let i = 2; i < subHeaderSize + 2; ++i) {
    sheet.getRange(i, 1, 1, sheet.getLastColumn()).setBackground("#666666");
    sheet.getRange(i, 1, 1, sheet.getLastColumn()).setFontColor("#FFFFFF");
  }

  // Color code the attendance
  for(let i = 0; i < cellValues.length; ++i) {
    for(let j = 0; j < cellValues[i].length; ++j) {
      const cellData = cellValues[i][j];
      const cellLocation = range.getCell(i + 1, j + 1);
      
      if(cellData === "Present") {
        cellLocation.setBackground("#D9EAD3");
      }
      else if(cellData === "Absent") {
        cellLocation.setBackground("#F4CCCC");
      }
      else if(cellData === "Excused") {
        cellLocation.setBackground("#FFF2CC");
      }
    }
  }
}

// Highlights waivers
function highlightWaivers() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getSheetByName("Waiver_Approval");
  const range = sheet.getDataRange();
  const cellValues = range.getValues();

  // Color headers blue
  if(!range.getBandings) range.applyRowBanding(SpreadsheetApp.BandingTheme.LIGHT_GREY);
  sheet.getRange(1, 1, 1, sheet.getLastColumn()).setBackground("#1C4587");
  sheet.getRange(1, 1, 1, sheet.getLastColumn()).setFontColor("#FFFFFF");

  // Highligh approval status
  for(let i = 1; i < cellValues.length; ++i) {
      const cellData = cellValues[i][10];
      const cellLocation = range.getCell(i + 1, 11);
      
      if(cellData === "Yes" || cellData === "yes") {
        cellLocation.setBackground("#D9EAD3");
      }
      else if(cellData === "No" || cellData === "no") {
        cellLocation.setBackground("#F4CCCC");
      }
      else {
        cellLocation.setBackground("#FFF2CC");
      }
  }
}

// Autoresponds to waivers submitted on incorrect dates
  function correctDates() {
    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = spreadsheet.getSheetByName("Waiver_Approval");
    const range = sheet.getDataRange();
    const cellValues = range.getValues();

    // Check through each date to see if it is a PMT event
    for(let i = 1; i < cellValues.length; ++i) {      const dateValue = new Date(cellValues[i][3]);
      
      const day = dateValue.getDay();
      const year = dateValue.getFullYear();

      const errorMessage = "This waiver was submitted for an invalid date. There is no " + cellValues[i][1] + " on " + cellValues[i][3] + ".Please submit a new waiver.";

      // Compares dates with PMT events and corrects if needed
      if(isNaN(dateValue.getTime()) || dateValue.getTime() === 0) Logger.log("No date included");
      else {
        if(day !== 1 && day !== 2 && day !== 4 && cellValues[i][1] === "PT") {
          sheet.getRange(i + 1, 11).setValue("No");
          sheet.getRange(i + 1, 12).setValue(errorMessage);
        }
        if(day !== 5 && cellValues[i][1] === "LLAB") {
          sheet.getRange(i + 1, 11).setValue("No");
          sheet.getRange(i + 1, 12).setValue(errorMessage);
        }
        if(year !== new Date().getFullYear()) {
          sheet.getRange(i + 1, 11).setValue("No");
          sheet.getRange(i + 1, 12).setValue(errorMessage);
        }
      }
    }
  spreadsheetFormatting();
}









