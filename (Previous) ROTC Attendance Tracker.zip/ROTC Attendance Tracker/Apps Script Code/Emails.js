// Email to remind flight commanders to take attendance
function attendanceReminderEmail() {
  const to = ["bklitzke@kent.edu", "achandl8@kent.edu", "mcharl10@kent.edu", "rcrim1@kent.edu", "aallenjr@kent.edu", "tbabik1@kent.edu", "crober79@kent.edu", "jhughe67@kent.edu", "dalnaama@kent.edu", "smcmanne@kent.edu"];
  const cc  = ["wpage4@kent.edu", "kroylo@kent.edu", "kwall5@kent.edu"];
  const bcc = ["srosen16@kent.edu"];
  const subject = "Attendance Reminder";
  const htmlBody = `
    <div style="max-width: 600px; margin: auto; background-color: #ffffff; border: 1px solid #ddd; border-radius: 8px; padding: 20px;">
      <div style="border-left: 6px solid #b30000; background-color: #fff3f3;
        padding: 12px 18px; border-radius: 6px; margin-bottom: 20px;">
        <p style="margin: 0; color: #b30000; font-weight: 700; font-size: 15px;">
          ⚠️ Automated Message Alert
        </p>
        <p style="margin: 4px 0 0 0; color: #444; font-size: 12px;">
          Please do not reply to this email.
        </p>
      </div>
      <div style="font-family: 'Verdana', sans-serif; font-size: 13px; color: #222; line-height: 1.5; border-radius: 4px;">
        <div style="background-color: #f9f9f9; padding: 20px;">
          <p>Good morning flight commanders,</p>
          <p>This is a reminder to record attendance at today's PMT event. </p>
          <p style="text-align: center; margin: 25px 0;">
            <a href="https://docs.google.com/forms/d/e/1FAIpQLSdTrJq9h7jPaLpaofH9zEXftBrEICtHC6cgSdMnoV_ce_-JAw/viewform?usp=header"
              target="_blank"
              style="background-color: #004CBA; color: #ffffff; padding: 12px 25px; border-radius: 6px; text-decoration: none; font-weight: bold; display: inline-block;">
              TAKE ATTENDANCE
            </a>
          </p>
          <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
          <p>Questions? Contact <a href="mailto:srosen16@kent.edu" style="color: #007bff; text-decoration: none;">srosen16@kent.edu</a>.</p>
        </div>
      </div>
    </div>
  `;

  if(PropertiesService.getScriptProperties().getProperty('Email Switch') === "ON") {
    MailApp.sendEmail({
      to: to.join(", "),
      cc: cc.join(", "),
      bcc: bcc.join(", "),
      subject: subject,
      htmlBody: htmlBody
    });
  }
}

// Email for PMT waiver status
function waiverStatusEmail() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getSheetByName("Waiver_Approval");
  const range = sheet.getDataRange();
  const cellValues = range.getValues();

  for(let i = 1; i < cellValues.length; ++i) { 
    const event = cellValues[i][1];
    const name = cellValues[i][2];
    const date = cellValues[i][3].toString().trim();
    approval = cellValues[i][10];
    const reason = cellValues[i][11];
    const emailSent = cellValues[i][12];
    const contact = "srosen16@kent.edu";

    // Determine approval
    if(approval === "Yes" || approval === "yes") {
      approval = "approved"
      reasonText = "";
    }
    else if(approval === "No" || approval === "no") {
      approval = "denied"
      reasonText = "<p>Reason: " + reason + "</p>"
    }
    
    const to  = [cellValues[i][4]];
    const cc  = [];
    const bcc = ["srosen16@kent.edu"];
    const subject = "PMT Waiver Status";

    const htmlBody = `
      <div style="max-width: 600px; margin: auto; background-color: #ffffff; border: 1px solid #ddd; border-radius: 8px; padding: 20px;">
        <div style="border-left: 6px solid #b30000; background-color: #fff3f3;
          padding: 12px 18px; border-radius: 6px; margin-bottom: 20px;">
          <p style="margin: 0; color: #b30000; font-weight: 700; font-size: 15px;">
            ⚠️ Automated Message Alert
          </p>
          <p style="margin: 4px 0 0 0; color: #444; font-size: 12px;">
            Please do not reply to this email.
          </p>
        </div>
        <div style="font-family: 'Verdana', sans-serif; font-size: 13px; color: #222; line-height: 1.5; border-radius: 4px;">
          <div style="background-color: #f9f9f9; padding: 20px;">
            <p>${name}, </p>
            <p>Your PMT waiver for <strong>${event}</strong> on <strong>${date}</strong> has been ${approval}.</p>
            ${reasonText}
            <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
            <p>Questions? Contact <a href="mailto:${contact}" style="color: #007bff; text-decoration: none;">${contact}</a>.</p>
          </div>
        </div>
      </div>
    `;

    if(emailSent !== "Sent" && (approval === "approved" || approval === "denied") && PropertiesService.getScriptProperties().getProperty('Email Switch') === "ON") {
      MailApp.sendEmail({
        to: to.join(", "),
        cc: cc.join(", "),
        bcc: bcc.join(", "),
        subject: subject,
        htmlBody: htmlBody
      });

      sheet.getRange(i + 1, 13).setValue("Sent");
    }
  }
}

// Make another email for Page
function atRiskCadetsEmail() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getSheetByName("Attendance");
  const range = sheet.getDataRange();
  const cellValues = range.getValues();

  // Add all cadet names into an array
  const cadets = [];
  for(let i = 2; i < cellValues[0].length; ++i) {
    const name         = cellValues[0][i];
    const ptAbsences   = cellValues[1][i];
    const llabAbsences = cellValues[2][i];

    const cadet = [name, ptAbsences, llabAbsences];
    cadets.push(cadet);
  }

  // Add cadets missing too many LLABs or PTs to a list
  const overPTCadets   = [];
  const overLLABCadets = [];
  for(let i = 0; i < cadets.length; ++i) {
    if(cadets[i][1] >= 8) {
      const pair = [cadets[i][0], cadets[i][1]];
      overPTCadets.push(pair);
    }
    if(cadets[i][2] >= 1) {
      const pair = [cadets[i][0], cadets[i][2]];
      overLLABCadets.push(pair);
    }
  }

  // Sorts the cadets who missed the most events to the top
  overPTCadets.sort((a, b) => b[1] - a[1]);
  overLLABCadets.sort((a, b) => b[1] - a[1]);

  // Formatt style of cadet table
  for(let i = 0; i < overPTCadets.length; ++i) overPTCadets[i] = "<tr>" + "<td style=\"border:0px solid #ccc; padding:8px;\">" + overPTCadets[i][0] + "</td>" + "<td style=\"border:0px solid #ccc; padding:8px;\">" + overPTCadets[i][1] + "</td>" + "</tr>";
  for(let i = 0; i < overLLABCadets.length; ++i) overLLABCadets[i] = "<tr>" + "<td style=\"border:0px solid #ccc; padding:8px;\">" + overLLABCadets[i][0] + "</td>" + "<td style=\"border:0px solid #ccc; padding:8px;\">" + overLLABCadets[i][1] + "</td>" + "</tr>";

  Logger.log(overPTCadets);
  Logger.log(overLLABCadets);

  const to = ["kroylo@kent.edu", "kwall5@kent.edu"];
  const cc  = [];
  const bcc = ["srosen16@kent.edu"];
  const subject = "Attendance Alert";
  const htmlBody = `
    <div style="max-width: 600px; margin: auto; background-color: #ffffff; border: 1px solid #ddd; border-radius: 8px; padding: 20px;">
      <div style="border-left: 6px solid #b30000; background-color: #fff3f3; padding: 12px 18px; border-radius: 6px; margin-bottom: 20px;">
        <p style="margin: 0; color: #b30000; font-weight: 700; font-size: 15px;">
          ⚠️ Automated Attendance Alert
        </p>
        <p style="margin: 4px 0 0 0; color: #444; font-size: 12px;">
          Please do not reply to this email.
        </p>
      </div>
      <div style="font-family: 'Verdana', sans-serif; font-size: 13px; color: #222; line-height: 1.5; border-radius: 4px;">
        <div style="background-color: #f9f9f9; padding: 20px;">
          <p>C/Roylo,</p>
          <p>The following cadets have exceeded allowed absences: </p>
          <div style="background-color: #FFFFFF; padding: 16px; border-radius: 4px; margin-top: 16px;">
            <h3 style="margin: 0 0 8px 0; color: #003366; font-size: 15px;">PT Absences (8+)</h3>
            <table style="width: 25%; border-collapse: collapse; font-family: Arial, sans-serif; font-size: 13px;">
              ${overPTCadets.join('')}
            </table>
          </div>
          <div style="background-color: #FFFFFF; padding: 16px; border-radius: 4px; margin-top: 16px;">
            <h3 style="margin: 0 0 1px 0; color: #003366; font-size: 15px;">LLAB Absences (1+)</h3>
            <table>
              <p>${overLLABCadets.join(' ')}</p>
            </table>
          </div>
          <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
          <p>Questions? Contact <a href="mailto:srosen16@kent.edu" style="color: #007bff; text-decoration: none;">srosen16@kent.edu</a>.</p>
        </div>
      </div>
    </div>
  `;

  if(PropertiesService.getScriptProperties().getProperty('Email Switch') === "ON") {
    MailApp.sendEmail({
      to: to.join(", "),
      cc: cc.join(", "),
      bcc: bcc.join(", "),
      subject: subject,
      htmlBody: htmlBody
    });
  }
}


















 
 
 




