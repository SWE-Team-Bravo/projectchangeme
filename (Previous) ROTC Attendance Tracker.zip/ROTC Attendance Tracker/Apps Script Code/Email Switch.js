// Turns the auto emails on and off
function toggleEmails() {
  if(PropertiesService.getScriptProperties().getProperty('Email Switch') === "ON") {
    PropertiesService.getScriptProperties().setProperty('Email Switch', "OFF")
  } else PropertiesService.getScriptProperties().setProperty('Email Switch', "ON")

  Logger.log("Email Switch: " + PropertiesService.getScriptProperties().getProperty('Email Switch'));
}


// Prints the current status of the email switch
function emailSwitchStatus() {
  Logger.log("Email Switch: " + PropertiesService.getScriptProperties().getProperty('Email Switch'));
}