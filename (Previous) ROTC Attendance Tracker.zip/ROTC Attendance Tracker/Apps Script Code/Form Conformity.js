function syncCadetNamesAcrossForms() {
  const inputFormId = '1h1uoP6RZ_sTRKDjPqJteaQTbdnnCaQemNMy82qrQS_0';   // Replace with your input form ID
  const outputFormId = '1a3WedvJijbEo_w--Im_fs__vehOMAXDaa_r6kNZQnaU'; // Replace with your output form ID

  const sectionTitles = ['Flight_1', 'Flight_2', 'Flight_3', 'Flight_4'];

  const inputForm = FormApp.openById(inputFormId);
  const outputForm = FormApp.openById(outputFormId);

  const inputItems = inputForm.getItems();
  const outputItems = outputForm.getItems();

  // Store cadet names and dropdowns by section
  let inputCadetNames = {};
  let outputDropdowns = {};

  // Initialize storage
  sectionTitles.forEach(section => {
    inputCadetNames[section] = [];
    outputDropdowns[section] = null;
  });

  // STEP 1: Extract cadet names from input form by section
  let currentInputSection = null;
  for (let i = 0; i < inputItems.length; i++) {
    const item = inputItems[i];

    if (item.getType() === FormApp.ItemType.PAGE_BREAK) {
      const sectionTitle = item.asPageBreakItem().getTitle();
      currentInputSection = sectionTitles.includes(sectionTitle) ? sectionTitle : null;
      continue;
    }

    if (currentInputSection && item.getType() === FormApp.ItemType.MULTIPLE_CHOICE) {
      inputCadetNames[currentInputSection].push(item.getTitle());
    }

    // Optional: stop at next section — not required here
  }

  // STEP 2: Locate dropdowns in output form by section
  let currentOutputSection = null;
  for (let i = 0; i < outputItems.length; i++) {
    const item = outputItems[i];

    if (item.getType() === FormApp.ItemType.PAGE_BREAK) {
      const sectionTitle = item.asPageBreakItem().getTitle();
      currentOutputSection = sectionTitles.includes(sectionTitle) ? sectionTitle : null;
      continue;
    }

    if (currentOutputSection && item.getType() === FormApp.ItemType.LIST && item.getTitle() === 'Name') {
      outputDropdowns[currentOutputSection] = item.asListItem();
    }
  }

  // STEP 3: Update each section's dropdown with corresponding cadet names
  sectionTitles.forEach(section => {
    const dropdown = outputDropdowns[section];
    const cadetNames = inputCadetNames[section];

    if (!dropdown) {
      Logger.log(`⚠️ Dropdown titled "Name" not found in section "${section}" of output form.`);
      return;
    }

    if (cadetNames.length === 0) {
      Logger.log(`⚠️ No cadet names found in section "${section}" of input form.`);
      return;
    }

    const choices = cadetNames.map(name => dropdown.createChoice(name));
    dropdown.setChoices(choices);
    Logger.log(`✅ Updated "${section}" dropdown with ${cadetNames.length} cadet names.`);
  });
}
