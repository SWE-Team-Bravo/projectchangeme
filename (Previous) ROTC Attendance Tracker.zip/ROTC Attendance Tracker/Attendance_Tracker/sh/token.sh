# uses the refresh token from the .evn file to generate a new refresh token
# and updates the .evn file

# loads .env for the file
source env/.env

# used .env to supply needed variables for refresh token to generate new
# token the parses the reponse json to return just the new token
NEW_TOKEN=$(curl -s -X POST https://oauth2.googleapis.com/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "client_id=${CLIENT_ID}" \
  -d "client_secret=${CLIENT_SECRET}" \
  -d "grant_type=refresh_token" \
  -d "refresh_token=${REFRESH_TOKEN}" \
  | grep -o '"access_token": *"[^"]*"' \
  | sed 's/"access_token": *"//; s/"$//')

# updates the .evn file with the new token
sed -i "s/^ACCESS_TOKEN=.*/ACCESS_TOKEN=\"${NEW_TOKEN}\"/" env/.env

: << 'COMMENTS'
+---------------------------------------------EXPLAINATION--------------------------------------------------+
**all data is found from https://developers.google.com/identity/protocols/oauth2/web-server#offline**

NEW_TOKEN=$(curl -s -X POST https://oauth2.googleapis.com/token \     // curl is used to make the HTTP request,
                                                                         -s makes it silent
                                                                         -X POST tells it to send data
                                                                         then the address that the data is being sent to is given
  -H "Content-Type: application/x-www-form-urlencoded" \              // -H is used to provide the HTTP header type
  -d "client_id=${CLIENT_ID}" \                                       // -d is used to provide data for the HTTP's body
  -d "client_secret=${CLIENT_SECRET}" \                               // -d is used to provide data for the HTTP's body
  -d "grant_type=refresh_token" \                                     // -d is used to provide data for the HTTP's body
  -d "refresh_token=${REFRESH_TOKEN}" \                               // -d is used to provide data for the HTTP's body
  | grep -o '"access_token": *"[^"]*"' \                              // grep is used to return a match based on given data
                                                                         used to pull only the access_token line from the json response
  | sed 's/"access_token": *"//; s/"$//')                             // sed is used to modify given data
                                                                         used to edit the part given by grep and removes the quotes

+---------------------------------------------EXPLAINATION--------------------------------------------------+
sed -i "s/^ACCESS_TOKEN=.*/ACCESS_TOKEN=\"${NEW_TOKEN}\"/" .env       // sed is used to modify given data
                                                                        -i tells sed to modify the file
                                                                        finds the string ACCESS_TOKEN and then modifies everything
                                                                          found between the quotations and replaces it with NEW_TOKEN
                                                                        .evn specifies the file that is being modified

COMMENTS