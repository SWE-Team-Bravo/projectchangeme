#include "attendance.hpp"

int main(int argc, char* argv[]) {
    if (argc != 12) {
        std::cerr << "2 input files and 1 output file is needed" << std::endl;
        return 1;
    }
    
    // Spreadsheets
    Spreadsheet           *waiverApproval      = new Spreadsheet(),
                          *manualCorrections   = new Spreadsheet();
    AttendanceSpreadsheet *attendance          = new AttendanceSpreadsheet();
    WaiverSpreadsheet     *waiver              = new WaiverSpreadsheet(),
                          *cadreWaiverApproval = new WaiverSpreadsheet();


    // Input/Output files
    ifstream attendanceData(argv[3]), waiverData(argv[4]), masterRosterData(argv[5]), waiverApprovalData(argv[6]), manualCorrectionsData(argv[7]), cadreWaiverData(argv[8]);
    ofstream cadreWaiverOutput(argv[argc - 3]), attendanceOutput(argv[argc - 2]), waiverOutput(argv[argc - 1]);

    // Grids
    manualCorrections->makeSheet(manualCorrectionsData);
    attendance->makeSheet(attendanceData);
    waiverApproval->makeSheet(waiverApprovalData);
    waiver->makeSheet(waiverData);
    cadreWaiverApproval->makeSheet(cadreWaiverData);

    // Sheet Operations
    attendance->manualCorrections(*manualCorrections);
    attendance->distributeExcused(*waiver, *waiverApproval, *cadreWaiverApproval);
    attendance->sortGrid();
    waiver->movePrivateWaivers(*cadreWaiverApproval);
    waiver->condenseWaiverSheet();
    cadreWaiverApproval->condenseWaiverSheet();
    
    // Export to sheets
    attendanceOutput << *attendance; 
    waiverOutput << *waiver;
    cadreWaiverOutput << *cadreWaiverApproval;

    return 0;
}