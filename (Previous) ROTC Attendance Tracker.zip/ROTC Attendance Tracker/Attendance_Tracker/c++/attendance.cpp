#include "attendance.hpp"

//
// Spreadsheet Class
//
 
// Copy Constructor
Spreadsheet::Spreadsheet(const Spreadsheet& copy) {
    grid_ = copy.grid_;
}

// Constant time swap
void Spreadsheet::swap(Spreadsheet& rhs) {
    vector<vector<string>> tempGrid_ = grid_;
    grid_ = rhs.grid_;
    rhs.grid_ = tempGrid_;
}

// Assignment copy
Spreadsheet& Spreadsheet::operator=(Spreadsheet rhs) {
    swap(rhs);
    return *this;
}

// Move constructor
Spreadsheet::Spreadsheet(Spreadsheet &&org) noexcept {
    grid_ = org.grid_;
    grid_ = vector<vector<string>>{};
}

// Removes JSON formatting
string Spreadsheet::removeJSONFormatting(string& JSONString) {
    // Extract part of string inside of quotes
    JSONString = JSONString.substr(JSONString.find("\"") + 1);
    JSONString = JSONString.substr(0, JSONString.find("\""));

    // Remove spaces and return the string
    // Return start or end tags if necessary
    string temp = JSONString;
    temp.erase(remove(temp.begin(), temp.end(), ' '), temp.end());
    if(temp == "]," || temp == "]" || temp == "[") return temp;
    else return JSONString;
}

// Transfers json data into useable grid
void Spreadsheet::makeSheet(std::ifstream& in) {
    std::string cellData;
    vector<string> row = {};
    bool useCellData = false;

    while(getline(in, cellData)) {
    cellData = removeJSONFormatting(cellData);
        if(useCellData == true) {
            if(cellData == "]") {                               // Stop using cell data when end is reached
                grid_.push_back(row);
                useCellData = false;   
            }     
            else if(cellData == "],") {                         // Adds row to grid_
                grid_.push_back(row);
                row = {};
            }
            else if(cellData != "[") row.push_back(cellData);   // Adds data to row
                
        }
        if(cellData == "values") useCellData = true;            // Starts using cell data when beginning is reached
    }

    evenGrid();
}

// Resizes grid_ to take advantage of the full sheet range
void Spreadsheet::evenGrid() {
    // Find the longest row
    int longestRow = 0;
    for(auto row : grid_) if(static_cast<int>(row.size()) > longestRow) longestRow = row.size();

    // Create a new grid with default values for empty rows
    vector<string>         tempRow(longestRow, "");
    vector<vector<string>> newGrid(grid_.size(), tempRow);

    // Add the contents of the old grid onto the new grid
    for(int i = 0; i < static_cast<int>(grid_.size()); ++i)
        for (int j = 0; j < static_cast<int>(grid_[i].size()); ++j) 
            newGrid[i][j] = grid_[i][j];

    grid_ = newGrid;
}

// Returns the location of a column
int Spreadsheet::findColumn(const Spreadsheet& sheet, const string& word) {
    int location = -1;
    for(size_t i = 0; i < sheet.grid_[0].size() && location == -1; ++i) 
        if(sheet.grid_[0][i].find(word) != string::npos) location = i;

    return location;
}

// Returns the location of a row
int Spreadsheet::findFirstData() {
    int firstData = -1;
    for(size_t i = 0; i < grid_.size() && firstData == -1; ++i)
        if((grid_[i][findColumn(*this, "C/")].find("Present")  != string::npos  ||
            grid_[i][findColumn(*this, "C/")].find("Absent")   != string::npos  ||
            grid_[i][findColumn(*this, "C/")].find("Excused")  != string::npos) &&
            grid_[i][findColumn(*this, "C/")].find("COUNTIFS") == string::npos) 
            firstData = i;

    return firstData;
}

// Overloaded function for << operator
std::ostream& operator<<(std::ostream& out,const Spreadsheet& sheet) {
    out.clear();
    std::vector<std::string>::const_iterator tempRow;
    
    string startTag    = "{\n  \"values\": [\n",
           endTag      = "  ]\n}",
           startRow    = "    [\n",
           endRow      = "    ],\n",
           endLastRow  = "    ]\n", 
           startCell   = "      \"",
           endCell     = "\",\n",
           endLastCell = "\"\n";
    

    out << startTag;
    
    // Reverts cell data back into json formatt
    for(auto row = sheet.grid_.begin(); row != sheet.grid_.end(); ++row) { 
        out << startRow;
        for(auto cell = row->begin(); cell != row->end(); ++cell) {
            if(next(cell, 1) != row->end()) out << startCell << *cell << endCell;
            else out << startCell << *cell << endLastCell;
        }
        if(next(row, 1) != sheet.grid_.end()) out << endRow;
        else out << endLastRow;
        
    }
    out << endTag;
    return out;
}

// Returns the data stored in a specified cell
string Spreadsheet::coordinates(const size_t& row, const string& column) {
    int intColumn = 0;
    // Converts column string into int that reflects a google spreadsheet
    for(auto ch : column) intColumn = intColumn * 26 + ch - 'A' + 1;    

    return grid_[static_cast<int>(row)][intColumn - 1];
}

// Returns the data stored in a specified cell
string Spreadsheet::coordinates(const size_t& row, const int& column) {
    return grid_[static_cast<int>(row)][column];
}

// Returns the grid
vector<vector<string>> Spreadsheet::getGrid() {
    return grid_;
}

// Returns all dates from dateStart to dateEnd
vector<string> Spreadsheet::dateRange(const string& start, const string& end) {
    // Set date for the start of range
    int monthS = stoi(start.substr(0, start.find("/"))), 
        dayS   = stoi(start.substr(start.find("/") + 1, start.rfind("/") - start.find("/") - 1)), 
        yearS  = stoi(start.substr(start.rfind("/") + 1, start.size() - 2));

    // Set date for end of range
    int monthE = stoi(end.substr(0, end.find("/"))), 
        dayE   = stoi(end.substr(end.find("/") + 1, end.rfind("/") - end.find("/") - 1)), 
        yearE  = stoi(end.substr(end.rfind("/") + 1, end.size() - 2));

    // Put start/end date into year_month_day type
    year_month_day ymdS{year{yearS}, month{static_cast<unsigned>(monthS)}, day{static_cast<unsigned>(dayS)}};
    year_month_day ymdE{year{yearE}, month{static_cast<unsigned>(monthE)}, day{static_cast<unsigned>(dayE)}};

    // Check that the date is valid
    if(!ymdS.ok() || !ymdE.ok()) cout << "invalid date" << endl;

    // Put star/end date into system days type
    sys_days startDay{ymdS};
    sys_days endDay{ymdE};

    // Increment through the days until end date is reached
    vector<string> result;
    for(sys_days d = startDay; d <= endDay; d += days{1}) {
        year_month_day ymd = year_month_day{d};

        // Extract raw values
        unsigned m = static_cast<unsigned>(ymd.month());
        unsigned d_ = static_cast<unsigned>(ymd.day());
        int y = int(ymd.year());

        // Format without leading zeros
        result.push_back(std::format("{}/{}/{}", m, d_, y));
    }

    return result;
}

// Adds all of the excused markers to the attendance sheet
void Spreadsheet::distributeExcused(Spreadsheet waiver, Spreadsheet waiverApproval, WaiverSpreadsheet cadreWaiverApproval) {    
    // Adds waiver names and dates into pairs and puts that into a vector 
    vector<pair<pair<bool, bool>, pair<pair<string, string>, pair<string, vector<string>>>>> absentPair = {};

    // Add cadre data back into waiver approval data for excused distribution
    for(auto itr = cadreWaiverApproval.grid_.begin() + 1; itr != cadreWaiverApproval.grid_.end(); ++itr) 
        waiverApproval.grid_.push_back(*itr);

    // Sort waiver and waiverApproval grids
    sort(waiver.grid_.begin() + 1, waiver.grid_.end(), [](const vector<string>& a, const vector<string>& b) {
        return a[0] < b[0];
    });
    sort(waiverApproval.grid_.begin() + 1, waiverApproval.grid_.end(), [](const vector<string>& a, const vector<string>& b) {
        return a[0] < b[0];
    });

    // This vector stores, 5 things, plus a range of dates if necessary
    // In order those things are: 
    /*
        1. Whether the waiver is standing/singluar
        2. Whether the waiver is approved or not
        3. The name of the cadet who submitted the waiver
        4. What event the waiver was submitted for
        5. Date of missed event
        6. A vector containing the list of days for standing waivers
    */
    for(auto row = waiver.grid_.begin() + 1, approvalRow = waiverApproval.grid_.begin() + 1; 
        (row != waiver.grid_.end()) && (approvalRow != waiverApproval.grid_.end()); 
        ++row, ++approvalRow) {
        if((*row)[findColumn(waiver, "Waiver Type")] == "Singular" || (*row)[findColumn(waiver, "Waiver Type")] == "Standing") {
            // Standing/Singular waivers
            bool standingWaiver = false;
            if((*row)[findColumn(waiver, "Waiver Type")] == "Standing") standingWaiver = true;

            // Approved or not
            bool approved = false;
            if((*approvalRow)[findColumn(waiverApproval, "Approved")] == "Yes" || (*approvalRow)[findColumn(waiverApproval, "Approved")] == "yes") approved = true;

            // Name on the waiver
            int name = 0;
            for(int i = findColumn(waiver, "Name"); i < findColumn(waiver, "Name") + 4; ++i) if((*row)[i] != "") name = i;

            // Find the dates for standing waivers and put them into a vector
            vector<string> standingDates = {};
            if(standingWaiver) standingDates = dateRange((*row)[findColumn(waiver, "Starting Date")], (*row)[findColumn(waiver, "Ending Date")]);

            // End of this part
            absentPair.push_back(pair(pair(standingWaiver, approved), pair(pair((*row)[name],(*row)[findColumn(waiver, "Event")]), pair((*row)[findColumn(waiver, "Date of missed event")], standingDates))));
        }
    }
    
    // Adds names to a vector
    vector<string> attendanceNames = {};
    for(size_t i = findColumn(*this, "C/"); i < grid_[0].size(); ++i) attendanceNames.push_back(grid_[0][i]);

    // Compares attendance names and dates to waiver names and dates
    for(size_t i = 1; i < grid_.size(); ++i) {
        int j = 0;
        string date = grid_[i][findColumn(*this, "Timestamp")], event = grid_[i][findColumn(*this, "Event")];
        for(auto name : attendanceNames) {
            ++j;
            for(auto absent : absentPair) {                
                if(absent.first.first) { // Standing Waivers
                    for(auto standingDate : absent.second.second.second) {
                        if(absent.second.first.first == name && 
                           absent.second.first.second == event &&
                           standingDate == date &&    
                           absent.first.second == true) {
                            grid_[i][j + findColumn(*this, "C/") - 1] = "Excused";
                        }  
                    }
                }
                else { // Singular Waivers
                    // if(absent.second.first.first == "C/So-Gilmore" && name == "C/So-Gilmore") {
                        // cout << absent.second.first.first  << "|" << name  << endl <<
                        //         absent.second.first.second << "|" << event << endl <<
                        //         absent.second.second.first << "|" << date  << endl << 
                        //         absent.first.second        << "|" << endl  << endl;
                    // }
                    if(absent.second.first.first == name && 
                       absent.second.first.second == event &&
                       absent.second.second.first == date &&    
                       absent.first.second == true) {
                        grid_[i][j + findColumn(*this, "C/") - 1] = "Excused";
                    }
                }
            }
        }
    }
}

void Spreadsheet::sortGrid() {
    int changes = 0;

    // Sorts columns into alphabetic order
    do {
        changes = 0;
        for(size_t i = findColumn(*this, "C/"); i < grid_[0].size(); ++i) {
            if(i + 1 < grid_[0].size()) {
                if(grid_[0][i] > grid_[0][i + 1]) {
                    ++changes;
                    for(auto& row : grid_) {
                        std::swap(row[i], row[i + 1]);
                    }
                }
            }  
        } 
    } while(changes > 0); 

    findFirstData();

    // Sorts rows into order of most recent date first
    do {
        changes = 0;
        for(size_t i = findFirstData(); i < grid_.size(); ++i) {
            if(i + 1 < grid_.size()) {
                // First date compared
                int monthA = stoi(grid_[i][0].substr(0, grid_[i][0].find("/"))), 
                    dayA   = stoi(grid_[i][0].substr(grid_[i][0].find("/") + 1, grid_[i][0].rfind("/") - grid_[i][0].find("/") - 1)), 
                    yearA  = stoi(grid_[i][0].substr(grid_[i][0].rfind("/") + 1, grid_[i][0].size() - 2));

                // Second date compared
                int monthB = stoi(grid_[i + 1][0].substr(0, grid_[i + 1][0].find("/"))), 
                    dayB   = stoi(grid_[i + 1][0].substr(grid_[i + 1][0].find("/") + 1, grid_[i + 1][0].rfind("/") - grid_[i + 1][0].find("/") - 1)), 
                    yearB  = stoi(grid_[i + 1][0].substr(grid_[i + 1][0].rfind("/") + 1, grid_[i + 1][0].size() - 2));

                year_month_day dateA{year{yearA}, month{static_cast<unsigned>(monthA)}, day{static_cast<unsigned>(dayA)}};
                year_month_day dateB{year{yearB}, month{static_cast<unsigned>(monthB)}, day{static_cast<unsigned>(dayB)}};
                
                if(dateA < dateB) {
                    ++changes;
                    std::swap(grid_[i], grid_[i + 1]);
                }
            }  
        } 
    } while(changes > 0);   
}

//
// Attendance Spreadsheet
//

void AttendanceSpreadsheet::manualCorrections(Spreadsheet manualData) {
    // Get manual name and date pairs
    vector<pair<string, string>> namePairs = {};
    for(size_t i = 1; i < manualData.getGrid().size(); ++i) {
        namePairs.push_back(pair(manualData.getGrid()[i][0], manualData.getGrid()[i][1]));
    }

    // Get manual event and date pairs
    vector<pair<string, string>> eventPairs = {};
    for(size_t i = 1; i < manualData.getGrid().size(); ++i) {
        eventPairs.push_back(pair(manualData.getGrid()[i][4], manualData.getGrid()[i][5]));
    }

    // Get manual date and date pairs
    vector<pair<string, string>> datePairs = {};
    for(size_t i = 1; i < manualData.getGrid().size(); ++i) {
        datePairs.push_back(pair(manualData.getGrid()[i][8], manualData.getGrid()[i][9]));
    }

    // Find attendance names
    vector<string> attendanceNames = {};
    for(size_t i = findColumn(*this, "C/"); i < grid_[0].size(); ++i) attendanceNames.push_back(grid_[0][i]);

    // Compare names
    for(size_t i = 0; i < grid_.size(); ++i) {
        int j = 0;
        string date = grid_[i][0];
        for(auto name : attendanceNames) {
            ++j;
            for(auto correctedName : namePairs) {                
                if(correctedName.first == date &&
                   correctedName.second == name ) {
                    grid_[i][j + findColumn(*this, "C/") - 1] = "Excused";
                }
            }
        }
    }

    // Compare events
    for(size_t i = 1; i < grid_.size(); ++i)
        for(auto event : eventPairs)
            if(event.first == grid_[i][0]) 
                grid_[i][1] = event.second;

    // Compare dates
    for(size_t i = 1; i < grid_.size(); ++i)
        for(auto date : datePairs)
            if(date.first == grid_[i][0]) 
                grid_[i][0] = date.second;
    
}

// Transfers json data into useable grid for attendance
void AttendanceSpreadsheet::makeSheet(std::ifstream& in) {
    Spreadsheet::makeSheet(in);
    condenseFlights();
    addAbsenceFormulas();
}

// Adds all of the absence formulas
void AttendanceSpreadsheet::addAbsenceFormulas() {
    // Containers for formulas and newGrid
    const int rowsAdded = 3;
    const string dataStart = std::to_string(rowsAdded + 2);
    vector<vector<string>> newGrid(grid_.size() + rowsAdded);
    vector<string> PTFormulas(grid_[0].size());
    vector<string> LLABFormulas(grid_[0].size());
    vector<string> waiverFormulas(grid_[0].size());

    // Fill the formula vectors with formulas
    generate(PTFormulas.begin() + findColumn(*this, "C/"), PTFormulas.end(), [dataStart]() { return "=COUNTIFS($B$" + dataStart + ":$B, \\\"PT\\\", INDIRECT(ADDRESS(" + dataStart + ", COLUMN()) & \\\":\\\" & ADDRESS(ROWS($A:$A), COLUMN())), \\\"Absent\\\")"; });
    generate(LLABFormulas.begin() + findColumn(*this, "C/"), LLABFormulas.end(), [dataStart]() { return "=COUNTIFS($B$" + dataStart + ":$B, \\\"LLAB\\\", INDIRECT(ADDRESS(" + dataStart + ", COLUMN()) & \\\":\\\" & ADDRESS(ROWS($A:$A), COLUMN())), \\\"Absent\\\")"; });
    generate(waiverFormulas.begin() + findColumn(*this, "C/"), waiverFormulas.end(), [dataStart]() { return "=COUNTIF(Waiver_Approval!C:C, INDIRECT(ADDRESS(1, COLUMN())))"; });

    // Fill the first row with the old first row, then add the
    // next three rows
    newGrid[0] = grid_[0];
    newGrid[1] = PTFormulas;
    newGrid[2] = LLABFormulas;
    newGrid[3] = waiverFormulas;

    // Add labels for rows 2 - 4 before the first names
    newGrid[1][findColumn(*this, "C/") - 2] = "PT Absences";
    newGrid[1][findColumn(*this, "C/") - 1] = "➡️";
    newGrid[2][findColumn(*this, "C/") - 2] = "LLAB Absences";
    newGrid[2][findColumn(*this, "C/") - 1] = "➡️";
    newGrid[3][findColumn(*this, "C/") - 2] = "Waivers Submitted";
    newGrid[3][findColumn(*this, "C/") - 1] = "➡️";

    // Add the rest of the rows into the new grid
    for(size_t i = rowsAdded + 1; i < newGrid.size(); ++i) newGrid[i] = grid_[i - rowsAdded];

    grid_ = newGrid;
}

// Condenses all flights into one row
void AttendanceSpreadsheet::condenseFlights() {
    vector<vector<string>> newGrid = {};
    map<string, vector<vector<string>>> dateDivider = {};

    // Removes the add/remove cadet columns
    for(size_t i = findColumn(*this, "C/"); i < grid_[0].size(); ++i) {
        if(grid_[0][i].find("C/") == string::npos) {
            for(auto& row : grid_)
                row.erase(row.begin() + i);
            --i;
        }
    } 

    // Find the column with flights in it
    int firstFlight = findColumn(*this, "Flight");

    for(auto& row : grid_) {
        row.erase(row.begin() + firstFlight);           // Removes flight names
        row[0] = row[0].substr(0, row[0].find(" "));    // Edits dates
        dateDivider[row[0]].push_back(row);             // Adds keys to dateDivider
    }

    // Adds similar dates together
    for(auto e : dateDivider) {
        vector<string> temp(e.second[0].size());
        for(auto a : e.second) {
            for(size_t i = 0; i < e.second[0].size(); ++i) {
                if(temp[i] == "") temp[i] = a[i];
            } 
        }
        newGrid.push_back(temp);
    }

    // Adds header back to front
    auto header = newGrid.back();
    newGrid.pop_back();
    newGrid.insert(newGrid.begin(), header);

    grid_ = newGrid;    
}

//
// Waiver Spreadsheet
//

// Transfers json data into useable grid for waiver
void WaiverSpreadsheet::makeSheet(std::ifstream& in) {
    Spreadsheet::makeSheet(in);
}

// Removes unwanted functions from the waivers
void WaiverSpreadsheet::condenseWaiverSheet() {
    // Removes the flight column
    int removeColumn = findColumn(*this, "Flight");
    for(auto& row : grid_) row.erase(row.begin() + removeColumn);

    // Removes the --- column
    removeColumn = findColumn(*this, "---");
    for(auto& row : grid_) row.erase(row.begin() + removeColumn);

    // Condenses names into single column
    vector<string> row;
    row.push_back("Name");
    for(size_t i = 1; i < grid_.size(); ++i) {
        for(size_t j = findColumn(*this, "Name"); j < static_cast<size_t>(findColumn(*this, "Name")) + 4; ++j) {
            if(grid_[i][j] != "") row.push_back(grid_[i][j]);
        }
    }

    // Put new row into grid_
    for(size_t i = 0; i < grid_.size(); ++i) grid_[i][findColumn(*this, "Name")] = row[i];

    // Removes extra name columns
    removeColumn = findColumn(*this, "Name");
    for(auto& row : grid_) {
        row.erase(row.begin() + removeColumn + 1);
        row.erase(row.begin() + removeColumn + 1);
        row.erase(row.begin() + removeColumn + 1);
    }
}

// Takes removes the private waivers from waiver and removes all but the private waiver from caderWaiver
void WaiverSpreadsheet::movePrivateWaivers(WaiverSpreadsheet& cadreWaivers) {
    cadreWaivers.grid_ = grid_;

    // Remove all non-private waivers
    for (auto it = cadreWaivers.grid_.begin(); it != cadreWaivers.grid_.end();) {
        if ((*it)[findColumn(cadreWaivers, "---")] == "No" || (*it)[findColumn(cadreWaivers, "---")] == "") {
            it = cadreWaivers.grid_.erase(it);  
        } else {
            ++it;
        }
    }

    // Remove all private waivers
    for (auto it = grid_.begin(); it != grid_.end();) {
        if ((*it)[findColumn(*this, "---")] == "Yes") {
            it = grid_.erase(it);  
        } else {
            ++it;
        }
    }
}

//
// Cadet Class
//

void Cadets::populateProfile(Spreadsheet attendance) {
    for(size_t i = 0; i < attendance.getGrid()[0].size(); ++i) {
        string cell = attendance.coordinates(0, i);
        
        // Used to populate the keys with cadet names
        if(cell.find("C/") != string::npos) profiles_[cell];
    }

    for(size_t i = 1; i < attendance.getGrid().size(); ++i) {
    
        
        string date, event, flight;
        date       = attendance.coordinates(i, 0);
        event      = attendance.coordinates(i, 1);
        flight     = attendance.coordinates(i, 2);

        vector<string> temp = {};
        temp.push_back(date);
        temp.push_back(event);
        temp.push_back(flight);

        for(size_t j = 3; j < attendance.getGrid()[i].size(); ++j) {
            string cell = attendance.coordinates(i,j);            
            string name = attendance.coordinates(0,j);
            
            auto it = profiles_.find(name);
            if(it != profiles_.end() && cell != "" && cell.find("\"\"") == string::npos) {
                if(temp.size() > 3) temp.pop_back();
                temp.push_back(cell);
                profiles_[name].push_back(temp);
            }
        }
    }
}

std::ostream& operator<<(std::ostream& out,const Cadets& temp) {
    out << "{\n  \"values\": [\n    [\n";

    auto it = temp.profiles_.find("C/Wall");
    if(it != temp.profiles_.end()) {
        out << "      \"" << it->first << "\"," << endl;

        auto vectorVectors = it->second;
        auto vectorStrings = vectorVectors[vectorVectors.size() - 1];
        auto flight        = vectorStrings[2]; 

        out << "      \"" << flight << "\"" << endl;
        out << "    ]," << endl << "    [" << endl;
        for(auto rowsVectorItr = it->second.begin(); rowsVectorItr != it->second.end(); ++ rowsVectorItr) {
            for(auto itr = rowsVectorItr->begin(); itr != rowsVectorItr->end(); ++itr) {
                if(itr->find("Flight") == string::npos) {
                    out << "      \"" << *itr << "\"";
                    if(next(itr, 1) != rowsVectorItr->end()) out << "," << endl;
                }
            }
            if(next(rowsVectorItr, 1) != it->second.end()) out << "\n    ]," << endl << "    [" << endl;
        } 
    }

    out << "\n    ]\n  ]\n}";

    return out;
}

void Cadets::generateProfileJSONS() {
    for(auto keys : profiles_) {
        std::ofstream out("profiles/" + keys.first.substr(2,keys.first.size()) + ".json");
        
        out << "{\n  \"values\": [\n    [\n";

        auto it = profiles_.find(keys.first);
        if(it != profiles_.end()) {
            out << "      \"" << it->first << "\"," << endl;

            auto vectorVectors = it->second;
            auto vectorStrings = vectorVectors[vectorVectors.size() - 1];
            auto flight        = vectorStrings[2]; 

            out << "      \"" << flight << "\"" << endl;
            out << "    ]," << endl << "    [" << endl;
            for(auto rowsVectorItr = it->second.begin(); rowsVectorItr != it->second.end(); ++ rowsVectorItr) {
                for(auto itr = rowsVectorItr->begin(); itr != rowsVectorItr->end(); ++itr) {
                    if(itr->find("Flight") == string::npos) {
                        out << "      \"" << *itr << "\"";
                        if(next(itr, 1) != rowsVectorItr->end()) out << "," << endl;
                    }
                }
                if(next(rowsVectorItr, 1) != it->second.end()) out << "\n    ]," << endl << "    [" << endl;
            } 
        }

        out << "\n    ]\n  ]\n}";  
    }
}