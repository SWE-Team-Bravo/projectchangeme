// Used to automate google sheets for Det 630 Attendance Tracker and PMT Waivers
// Charles Gale
// 9/22/2025

#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <map>
#include <algorithm>
#include <utility>
#include <iterator>
#include <fstream>
#include <chrono>
#include <format>

using std::vector, std::string, std::cout, std::endl, std::getline, std::map,
      std::stoi, std::pair, std::next, std::fstream, std::ios, std::fstream,
      std::ifstream, std::ofstream, std::cerr, std::ostream, std::format;
using namespace std::chrono;

class AttendanceSpreadsheet;
class WaiverSpreadsheet;  // forward declaration

// Used to formatt the data from import files into something usefull
class Spreadsheet {
public:
                           Spreadsheet          (                                           ) : grid_({}) {};    // Default constructor for an empty grid_
                           Spreadsheet          (const Spreadsheet&                         )               ;    // Copy Constructor
    void                   swap                 (Spreadsheet&                               )               ;    // Constant time swap
    Spreadsheet&           operator=            (Spreadsheet                                )               ;    // Assignment copy
                           Spreadsheet          (Spreadsheet &&                             ) noexcept      ;    // Move constructor
    virtual                ~Spreadsheet         (                                           ) = default     ;    // Virtual destructor
          
    virtual void           makeSheet            (std::ifstream&                             )               ;    // Transfers json data into useable grid
    string                 removeJSONFormatting (string&                                    )               ;    // Removes the JSON formatting
          
    string                 coordinates          (const size_t&, const string&               )               ;    // Returns the data stored in a specified cell
    string                 coordinates          (const size_t&, const int&                  )               ;    // Returns the data stored in a specified cell
    vector<vector<string>> getGrid              (                                           )               ;    // Returns the grid

    void                   distributeExcused    (Spreadsheet, Spreadsheet, WaiverSpreadsheet)               ;    // Updates the attendance sheet based on the absent/excused sheet
    vector<string>         dateRange            (const string&, const string&               )               ;    // Returns a range of dates from an intital start date and end date
    void                   sortGrid             (                                           )               ;    // Sorts the grid from newest date to oldest date

    friend std::ostream&   operator<<           (ostream&, const Spreadsheet&               )               ;    // Overloaded function for << operator

    int                    findColumn           (const Spreadsheet&, const string&          )               ;    // Returns the location of a column in a spreadsheet
    int                    findFirstData        (                                           )               ;    // Returns the location of the first row that isn't a header
protected:
    void                   evenGrid             (                                           )               ;    // Resizes grid_ so that each cell can be accessed
    vector<vector<string>> grid_;   // Holds all rows

private:
};

class AttendanceSpreadsheet : public Spreadsheet {
public:
    void                   makeSheet            (std::ifstream&              ) override              ;    // Transfers json data into useable grid
    void                   manualCorrections    (Spreadsheet                 )                       ;    // Manuals correct mistakes in the sheets
protected:    
    void                   condenseFlights      (                            )                       ;    // Condenses all flights into one row                    
    void                   addAbsenceFormulas   (                            )                       ;    // Adds all of the absence formulas
};

class WaiverSpreadsheet : public Spreadsheet {
public:
    void                   makeSheet            (std::ifstream&              ) override              ;    // Transfers json data into useable grid
    void                   condenseWaiverSheet  (                            )                       ;    // Hides all of the non-usefull data
    void                   movePrivateWaivers   (WaiverSpreadsheet&          )                       ;    // Moves all of the private waivers to the cadre sheet
protected:    
};

class Cadets {
public:
    Cadets() : profiles_({}) {};

    void populateProfile(Spreadsheet);
    void generateProfileJSONS();
    
    friend std::ostream& operator<<(ostream&, const Cadets&);
private:
map<string, vector<vector<string>>> profiles_;
};